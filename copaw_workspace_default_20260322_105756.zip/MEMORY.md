---
summary: "Agent 长期记忆 — 工具设置与经验教训"
read_when:
  - 手动引导工作区
---

## 工具设置

Skills 定义工具怎么用。这文件记你的具体情况 — 你独有的设置。

### 学术文献搜索

#### 常用数据库

| 数据库 | 领域 | 优先级 | 可用性 |
|--------|------|--------|--------|
| **ArXiv** | 物理/计算机/数学 | ⭐⭐⭐⭐⭐ | ✅ qinyan-paper-search |
| **Google Scholar** | 综合 | ⭐⭐⭐⭐⭐ | ✅ qinyan-paper-search |
| **万方** | 中文综合 | ⭐⭐⭐⭐ | ✅ qinyan-paper-search |
| **PubMed** | 医学/生物 | ⭐⭐⭐⭐ | ✅ qinyan-paper-search |
| **Semantic Scholar** | 综合/AI | ⭐⭐⭐⭐ | ✅ 浏览器直接访问 |
| **PMC (PubMed Central)** | 医学/生物 | ⭐⭐⭐⭐ | ✅ 浏览器直接访问 |
| **Nature** | 综合科学 | ⭐⭐⭐⭐ | ✅ 浏览器直接访问 |
| **Web of Science** | 综合索引 | ⭐⭐⭐ | ✅ 浏览器直接访问 |
| **NASA/ADS** | 天体物理/航天 | ⭐⭐⭐ | ⚠️ 加载较慢 |
| **Springer** | 理工/医学 | ⭐⭐⭐ | ✅ 浏览器直接访问 |
| **Elsevier** | 理工/医学 | ⭐⭐⭐ | ✅ 浏览器直接访问 |
| **ProQuest** | 博硕士论文/社科 | ⭐⭐⭐ | ⚠️ 需机构权限 |
| **ORCID** | 作者ID | ⭐⭐ | ✅ 浏览器直接访问 |
| **IEEE/ACM** | CS/工程 | ⭐⭐ | ❌ 拒绝访问 |
| **Scopus** | 综合索引 | ⭐⭐ | ❌ Cloudflare 阻止 |
| **ScienceDirect** | 理工/医学 | ⭐⭐ | ❌ 需联系支持 |
| **SPIE** | 光学/光子学 | ⭐⭐ | ❌ 反爬虫保护 |
| **OPTICA (OSA)** | 光学/光子学 | ⭐⭐ | ❌ 验证码拦截 |
| **Wiley** | 理工/医学 | ⭐⭐ | ❌ Cloudflare 阻止 |
| **Science** | 综合科学 | ⭐⭐ | ❌ Cloudflare 验证 |
| **MDPI** | 开放获取 | ⭐⭐ | ❌ 拒绝访问 |
| **ResearchGate** | 学术社交 | ⭐⭐ | ❌ 拒绝访问 |
| **IOPScience** | 物理 | ⭐⭐ | ❌ 验证码拦截 |

#### qinyan-paper-search 使用方法

```bash
# 进入skill目录
cd /home/junsheng/.copaw/workspaces/default/active_skills/qinyan-paper-search

# 调用格式
bash scripts/search.sh <source> '<json_payload>'

# 参数说明
# source: google | wanfang | pubmed | arxiv
# query: 搜索关键词
# max_results: 返回数量 (默认10)

# 示例 - 搜索量子计算
bash scripts/search.sh arxiv '{"query": "quantum computing", "max_results": 10}'
bash scripts/search.sh google '{"query": "quantum computing", "max_results": 10}'
bash scripts/search.sh wanfang '{"query": "量子计算", "max_results": 10}'
bash scripts/search.sh pubmed '{"query": "quantum computing", "max_results": 10}'
```

#### 检索策略

- **英文理工科**（量子计算、物理、计算机）：优先 ArXiv + Google Scholar
- **英文医学/生物**：优先 PubMed + Google Scholar
- **中文查询**：优先万方 + Google Scholar
- **光学/光子学领域**：SPIE/OPTICA 有反爬虫，建议通过 Google Scholar 搜索跳转

#### 工具优先级排名

**第一梯队（推荐）：**
1. **qinyan-paper-search (ArXiv)** — 最快，最适合理工科 preprint
2. **qinyan-paper-search (Google Scholar)** — 综合最强，涵盖各类文献
3. **qinyan-paper-search (万方)** — 中文文献首选
4. **qinyan-paper-search (PubMed)** — 医学/生物相关

**第二梯队（浏览器直接访问）：**
5. **Semantic Scholar** — AI 增强的综合搜索
6. **PMC** — 免费医学/生物全文
7. **Nature** — 高影响力期刊
8. **Web of Science** — 综合索引数据库

**第三梯队（需特殊条件）：**
9. **Springer / Elsevier** — 出版商平台，需机构权限
10. **ProQuest** — 需机构权限

**不推荐（反爬虫/验证码）：**
11. SPIE、OPTICA、IOPScience、Wiley、Science、Scopus、MDPI、ResearchGate、IEEE、ScienceDirect

#### 测试结果 (2026-03-22) - 量子计算搜索

| 数据源 | 状态 | 方式 |
|--------|------|------|
| ArXiv | ✅ | qinyan-paper-search |
| Google Scholar | ✅ | qinyan-paper-search |
| 万方 | ✅ | qinyan-paper-search |
| PubMed | ✅ | qinyan-paper-search |
| Semantic Scholar | ⚠️ | 浏览器(超时) |
| PMC | ✅ | 浏览器 |
| Nature | ✅ | 浏览器 |
| Web of Science | ⚠️ | 浏览器(需验证) |
| Springer | ✅ | 浏览器 |
| Elsevier | ❌ | 浏览器(错误) |
| NASA/ADS | ⚠️ | 浏览器(加载慢) |
| ProQuest | ✅ | 浏览器(需操作) |
| ORCID | ✅ | 浏览器 |
| IEEE | ❌ | 拒绝访问 |
| Scopus | ❌ | Cloudflare |
| ScienceDirect | ❌ | 需联系支持 |
| SPIE | ❌ | 反爬虫 |
| OPTICA | ❌ | 验证码 |
| Wiley | ❌ | Cloudflare |
| Science | ❌ | Cloudflare |
| MDPI | ❌ | 拒绝访问 |
| ResearchGate | ❌ | 拒绝访问 |
| IOPScience | ❌ | 验证码 |

#### 量子计算搜索效果对比 (2026-03-22)

| 数据库 | 关键词 | 返回结果数 | 响应时间 | 备注 |
|--------|--------|-----------|---------|------|
| **ArXiv** | quantum computing | ~15篇 | ~3s | 前沿preprint，含最新研究 |
| **Google Scholar** | quantum computing | ~15篇 | ~5s | 综合最强，含经典文献 |
| **万方** | 量子计算 | ~15篇 | ~4s | 中文综述性文章 |
| **PubMed** | quantum computing | ~15篇 | ~4s | 医学交叉领域 |
| **PMC** | quantum computing | 178,587条 | ~5s | 医学/生物全文库 |
| **Nature** | quantum computing | 18,087条 | ~5s | 高影响力期刊 |
| **Springer** | quantum computing | 127,630条 | ~5s | 理工科全面 |
| **ProQuest** | quantum computing | 需手动 | - | 硕博士论文 |
| **Web of Science** | quantum computing | 需验证 | - | 综合索引 |
| **NASA/ADS** | quantum computing | 加载慢 | - | 天体物理/量子物理 |

#### 搜索效果评价

**最佳体验 (qinyan-paper-search)：**
- **ArXiv** ⭐⭐⭐⭐⭐ — 最快最新，理工科首选
- **Google Scholar** ⭐⭐⭐⭐⭐ — 综合最强，经典文献全
- **万方** ⭐⭐⭐⭐ — 中文文献首选
- **PubMed** ⭐⭐⭐⭐ — 医学/生物交叉领域

**浏览器端推荐：**
- **PMC** ⭐⭐⭐⭐ — 结果最多，免费全文
- **Nature** ⭐⭐⭐⭐ — 权威期刊，质量高
- **Springer** ⭐⭐⭐⭐ — 全面覆盖

**需优化：**
- Semantic Scholar 加载超时
- Web of Science 需要人机验证
- NASA/ADS 加载缓慢
- Elsevier ScienceDirect 访问出错