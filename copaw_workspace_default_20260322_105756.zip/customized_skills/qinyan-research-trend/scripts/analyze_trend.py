#!/usr/bin/env python3
"""
沁言学术 - 研究趋势量化分析脚本
用法: cat papers.json | python3 analyze_trend.py
或: python3 analyze_trend.py < papers.json
输入: JSON格式的文献列表（从search.sh输出）
"""
import json
import collections
import sys


def analyze_trends(papers):
    """分析文献列表的趋势数据"""

    print(f"共分析 {len(papers)} 篇文献\n")

    # 1. 年度发文量统计
    year_counts = collections.Counter()
    for p in papers:
        year = str(p.get('year') or p.get('pub_year') or p.get('publication_year', ''))
        if year and year.isdigit():
            year_counts[year] += 1

    if year_counts:
        print("=== 年度发文量趋势 ===")
        max_count = max(year_counts.values())
        for year in sorted(year_counts.keys()):
            count = year_counts[year]
            bar_len = int(count / max_count * 40) if max_count > 0 else 0
            bar = '█' * bar_len
            print(f"  {year}: {bar} ({count}篇)")
        print()

    # 2. 高频作者统计
    author_counts = collections.Counter()
    for p in papers:
        authors = p.get('authors', [])
        if isinstance(authors, list):
            for a in authors[:3]:
                if isinstance(a, str) and a.strip():
                    author_counts[a.strip()] += 1
                elif isinstance(a, dict):
                    name = a.get('name', '')
                    if name:
                        author_counts[name] += 1

    if author_counts:
        print("=== 高频作者 TOP 10 ===")
        for author, count in author_counts.most_common(10):
            print(f"  {author}: {count}篇")
        print()

    # 3. 标题关键词词频
    word_counts = collections.Counter()
    stopwords = {
        'the', 'of', 'and', 'in', 'for', 'a', 'to', 'with', 'on', 'is',
        'an', 'by', 'from', 'as', 'that', 'are', 'at', 'its', 'be', 'or',
        'it', 'this', 'was', 'were', 'been', 'has', 'have', 'not', 'but',
        'can', 'using', 'based', 'via', 'into', 'between', 'through', 'our',
        'we', 'their', 'these', 'which', 'more', 'than', 'also', 'about',
    }
    for p in papers:
        title = p.get('title', '')
        if title:
            words = title.lower().split()
            for w in words:
                w = w.strip('.,;:()[]"\'-?!')
                if len(w) > 2 and w not in stopwords and w.isalpha():
                    word_counts[w] += 1

    if word_counts:
        print("=== 高频标题关键词 TOP 15 ===")
        for word, count in word_counts.most_common(15):
            print(f"  {word}: {count}次")
        print()

    # 4. 来源期刊/会议统计
    venue_counts = collections.Counter()
    for p in papers:
        venue = (p.get('publication_journal') or p.get('journal') or
                 p.get('venue') or p.get('publication', ''))
        if isinstance(venue, str) and venue.strip():
            venue_counts[venue.strip()] += 1

    if venue_counts:
        print("=== 主要发表来源 TOP 10 ===")
        for venue, count in venue_counts.most_common(10):
            print(f"  {venue}: {count}篇")
        print()


def main():
    try:
        data = json.load(sys.stdin)
    except json.JSONDecodeError as e:
        print(f"Error: 无法解析JSON输入 - {e}", file=sys.stderr)
        sys.exit(1)

    if isinstance(data, list):
        papers = data
    elif isinstance(data, dict):
        # 沁言学术API返回格式: {"success":true, "results":{"total":N}, "data":[...]}
        # 优先取 data 字段（论文列表），results 字段是元数据非论文列表
        candidates = [data.get('data'), data.get('papers'), data.get('results')]
        papers = next((c for c in candidates if isinstance(c, list) and c), [])
    else:
        print("Error: 不支持的数据格式", file=sys.stderr)
        sys.exit(1)

    if not papers:
        print("Warning: 未找到论文数据")
        sys.exit(0)

    analyze_trends(papers)


if __name__ == '__main__':
    main()
