---
name: qinyan-research-trend
description: "沁言学术研究趋势分析 - 通过沁言学术OpenAPI大量检索文献，结合Python数据分析，生成某领域的研究热点演变、发文量趋势、核心作者/机构分布等量化分析报告。触发词：研究趋势、趋势分析、热点分析、research trend、热点追踪、领域分析、学术热点、bibliometric"
version: 1.0.0
---

# 沁言学术 - 研究趋势分析

## 概述

本技能通过沁言学术OpenAPI从多个学术数据库大量检索文献，结合Python数据分析脚本，对特定研究领域进行量化趋势分析。生成包含发文量趋势、研究热点演变、核心作者/机构分布等内容的分析报告。

**学术诚信声明：** 所有分析基于真实检索到的文献数据，统计结果如实呈现。由于检索覆盖面的局限性，分析结果为近似趋势，不代表领域的完全精确画像。

## 前置条件

使用前请确保：
1. 已设置 `QINYAN_API_KEY` 环境变量（前往 https://platform.qinyanai.com/ 申请）
2. 环境中可用 `curl` 和 `python3`

```bash
export QINYAN_API_KEY="your-api-key-here"
```

## 工作流程

### 第一步：确定分析范围

与用户确认：
- **研究领域/主题**：要分析的具体领域
- **时间跨度**：分析的年份范围（建议5-10年以观察趋势）
- **分析维度**：发文量趋势 / 热点关键词 / 核心作者 / 核心期刊 等
- **关注地区**：是否侧重中文/英文学术圈

### 第二步：大规模文献检索

使用 `scripts/search.sh` 进行系统化检索，按**不同年份区间**分批检索以获取时间维度数据。

```bash
bash scripts/search.sh <source> '<json_payload>'
# source: google | wanfang | pubmed | arxiv
```

**分年检索策略示例：**
```bash
# 按年份分批检索以获取时间趋势数据
bash scripts/search.sh arxiv '{"query": "federated learning", "max_results": 100, "date_from": "2019", "date_to": "2020"}'
bash scripts/search.sh arxiv '{"query": "federated learning", "max_results": 100, "date_from": "2020", "date_to": "2021"}'
bash scripts/search.sh arxiv '{"query": "federated learning", "max_results": 100, "date_from": "2021", "date_to": "2022"}'
bash scripts/search.sh arxiv '{"query": "federated learning", "max_results": 100, "date_from": "2022", "date_to": "2023"}'
bash scripts/search.sh arxiv '{"query": "federated learning", "max_results": 100, "date_from": "2023", "date_to": "2024"}'
bash scripts/search.sh arxiv '{"query": "federated learning", "max_results": 100, "date_from": "2024", "date_to": "2025"}'

# 同时检索中文文献
bash scripts/search.sh wanfang '{"query": "联邦学习", "max_results": 100, "date_from": "2019", "date_to": "2022"}'
bash scripts/search.sh wanfang '{"query": "联邦学习", "max_results": 100, "date_from": "2022", "date_to": "2025"}'
```

**各数据库参数：**

| 数据源 | 命令 | 核心参数 |
|--------|------|----------|
| Google Scholar | `bash scripts/search.sh google '<json>'` | query, max_results(≤20), date_from, date_to |
| 万方 | `bash scripts/search.sh wanfang '<json>'` | query, max_results(≤100), date_from, date_to |
| PubMed | `bash scripts/search.sh pubmed '<json>'` | query(英文), max_results(≤200), date_from, date_to |
| ArXiv | `bash scripts/search.sh arxiv '<json>'` | query(英文), max_results(≤100), date_from, date_to |

### 第三步：Python数据分析

使用Python脚本对检索结果进行量化分析：

```python
#!/usr/bin/env python3
"""研究趋势量化分析脚本"""
import json
import collections
import sys

def analyze_trends(papers):
    """分析文献列表的趋势数据"""

    # 1. 年度发文量统计
    year_counts = collections.Counter()
    for p in papers:
        year = p.get('year') or p.get('pub_year', 'unknown')
        if year and year != 'unknown':
            year_counts[str(year)] = year_counts.get(str(year), 0) + 1

    print("=== 年度发文量趋势 ===")
    for year in sorted(year_counts.keys()):
        bar = '█' * min(year_counts[year], 50)
        print(f"  {year}: {bar} ({year_counts[year]}篇)")

    # 2. 高频作者统计
    author_counts = collections.Counter()
    for p in papers:
        authors = p.get('authors', [])
        if isinstance(authors, list):
            for a in authors[:3]:  # 取前三作者
                if isinstance(a, str) and a.strip():
                    author_counts[a.strip()] += 1

    print("\n=== 高频作者 TOP 10 ===")
    for author, count in author_counts.most_common(10):
        print(f"  {author}: {count}篇")

    # 3. 关键词/标题词频分析
    word_counts = collections.Counter()
    stopwords = {'the','of','and','in','for','a','to','with','on','is','an','by','from','as','that','are','at','its','be','or','it','this','was','were','been'}
    for p in papers:
        title = p.get('title', '')
        if title:
            words = title.lower().split()
            for w in words:
                w = w.strip('.,;:()[]"\'')
                if len(w) > 2 and w not in stopwords:
                    word_counts[w] += 1

    print("\n=== 高频标题关键词 TOP 15 ===")
    for word, count in word_counts.most_common(15):
        print(f"  {word}: {count}次")

    # 4. 来源期刊/会议统计
    venue_counts = collections.Counter()
    for p in papers:
        venue = p.get('journal') or p.get('venue') or p.get('source', '')
        if venue and venue.strip():
            venue_counts[venue.strip()] += 1

    if venue_counts:
        print("\n=== 主要发表来源 TOP 10 ===")
        for venue, count in venue_counts.most_common(10):
            print(f"  {venue}: {count}篇")

if __name__ == '__main__':
    # 从标准输入或文件读取JSON数据
    data = json.load(sys.stdin)
    papers = data if isinstance(data, list) else data.get('results', data.get('papers', []))
    analyze_trends(papers)
```

### 第四步：生成趋势分析报告

## 输出格式

```
# [研究领域] 研究趋势分析报告

## 1. 分析概况
- 检索数据库：[使用的数据库]
- 时间范围：[起止年份]
- 检索文献总量：[数量]

## 2. 发文量趋势
[年度发文量变化描述和趋势判断]
[文字版柱状图或表格]

## 3. 研究热点演变
### 3.1 早期阶段（YYYY-YYYY）
[该阶段的主要研究主题和代表性工作]

### 3.2 发展阶段（YYYY-YYYY）
[该阶段的研究热点转变]

### 3.3 近期趋势（YYYY-至今）
[当前最新研究热点和前沿方向]

## 4. 核心研究力量
### 4.1 高产作者
[高频作者列表及其主要研究方向]

### 4.2 主要发表来源
[核心期刊/会议列表]

## 5. 关键技术/方法演变
[该领域主要技术路线的发展脉络]

## 6. 研究前沿与展望
[基于趋势分析，预判未来研究方向]

## 参考文献
[引用的代表性文献列表]
```

## 分析质量要求

1. **数据充分**：每个时间段至少检索50-100篇文献
2. **多源验证**：尽量从多个数据库交叉验证趋势
3. **定量+定性**：统计数据结合内容分析
4. **趋势判断有据**：避免无依据的推测
5. **时间粒度合理**：根据领域发展速度选择年/半年粒度

## 示例工作流

```
用户: 分析一下"联邦学习"领域近5年的研究趋势

步骤1: 确认范围 → 联邦学习，2020-2025，全面分析

步骤2: 分年份、分数据库检索
- ArXiv: 按年份分批检索 (每年100条)
- Google Scholar: 补充检索 (每年20条)
- 万方: 中文文献检索 (每年100条)

步骤3: Python量化分析
- 年度发文量统计
- 高频作者分析
- 热点关键词变化
- 期刊/会议分布

步骤4: 生成趋势分析报告
```
