---
name: qinyan-literature-review
description: "沁言学术文献综述生成 - 基于沁言学术OpenAPI大量检索文献，自动生成结构化的文献综述报告，包括研究背景、研究现状分类梳理、研究趋势、研究不足与展望。支持中英文输出，可生成完整综述初稿。触发词：文献综述、综述生成、literature review、写综述、生成综述、研究综述、综述报告"
version: 1.0.0
---

# 沁言学术 - 文献综述生成

## 概述

本技能通过沁言学术OpenAPI从多个学术数据库大量检索文献，结合AI分析能力，自动生成结构化的文献综述报告。适用于学位论文的文献综述章节、独立综述论文撰写、项目申请书中的研究现状部分等场景。

**学术诚信声明：**
- 综述中引用的所有文献均来自真实检索结果，严禁捏造文献
- 综述内容基于检索文献的实际信息进行归纳总结
- 生成的综述为初稿性质，需作者审核、修改和完善
- 不替代作者对领域的深度理解和独立思考

## 前置条件

使用前请确保：
1. 已设置 `QINYAN_API_KEY` 环境变量（前往 https://platform.qinyanai.com/ 申请）
2. 环境中可用 `curl` 和 `python3`

```bash
export QINYAN_API_KEY="your-api-key-here"
```

## 工作流程

### 第一步：明确综述范围

与用户确认：
- **研究主题/领域**：具体的研究方向
- **时间范围**：关注的年份区间（如近5年）
- **综述类型**：系统综述 / 叙述性综述 / 范围综述
- **输出语言**：中文 / 英文
- **目标用途**：学位论文章节 / 独立综述论文 / 申请书

### 第二步：系统化文献检索

使用 `scripts/search.sh` 从多个数据库进行**多轮、多关键词**检索，确保文献覆盖面。

```bash
# 检索脚本用法
bash scripts/search.sh <source> '<json_payload>'
# source: google | wanfang | pubmed | arxiv
```

**检索策略：**

1. **核心关键词检索**：使用主题的核心关键词
2. **同义词/近义词扩展**：扩展检索词覆盖不同表述
3. **子主题拆分检索**：将大主题拆分为多个子方向分别检索
4. **中英文双语检索**：中文领域需同时检索中英文文献

**各数据库参数：**

| 数据源 | 命令 | 核心参数 | 说明 |
|--------|------|----------|------|
| Google Scholar | `bash scripts/search.sh google '<json>'` | query, max_results(≤20), date_from, date_to, author | 综合学术 |
| 万方 | `bash scripts/search.sh wanfang '<json>'` | query, max_results(≤100), date_from, date_to | 中文文献 |
| PubMed | `bash scripts/search.sh pubmed '<json>'` | query(英文), max_results(≤200), date_from, date_to | 医学生物 |
| ArXiv | `bash scripts/search.sh arxiv '<json>'` | query(英文), max_results(≤100), date_from, date_to, author | 理工计算机 |

**注意：PubMed和ArXiv不支持中文检索，需将查询词翻译为英文。**

```bash
# 示例：围绕"大语言模型在教育中的应用"进行多轮检索
bash scripts/search.sh google '{"query": "large language models education", "max_results": 20, "date_from": "2022"}'
bash scripts/search.sh arxiv '{"query": "LLM education tutoring assessment", "max_results": 100, "date_from": "2022"}'
bash scripts/search.sh wanfang '{"query": "大语言模型 教育应用", "max_results": 100, "date_from": "2022"}'
bash scripts/search.sh google '{"query": "ChatGPT education learning", "max_results": 20, "date_from": "2022"}'
bash scripts/search.sh pubmed '{"query": "artificial intelligence medical education", "max_results": 100, "date_from": "2022"}'
```

### 第三步：文献筛选与分类

对检索到的文献进行：
1. **去重**：合并不同数据库的重复文献
2. **相关性筛选**：排除与主题不相关的文献
3. **质量筛选**：优先保留高影响力期刊/会议论文
4. **主题分类**：将文献按研究子方向/方法类型进行归类

### 第四步：生成文献综述

基于分类整理的文献，按结构化模板生成综述。

### 第五步（可选）：使用Python生成统计图表

可通过执行Python脚本，生成文献的年份分布图、研究方向分布图等可视化内容。

```python
# 示例：生成文献年份分布统计
import json
import collections

# 假设 papers 为检索结果列表
year_counts = collections.Counter(p.get('year', 'unknown') for p in papers)
for year in sorted(year_counts.keys()):
    print(f"{year}: {'█' * year_counts[year]} ({year_counts[year]}篇)")
```

## 输出格式

```
# [研究主题] 文献综述

## 1. 引言
[研究背景和综述目的，说明该领域的重要性和综述的必要性]

## 2. 研究现状
### 2.1 [子方向1名称]
[该子方向的研究进展梳理，引用具体文献]

### 2.2 [子方向2名称]
[该子方向的研究进展梳理，引用具体文献]

### 2.3 [子方向3名称]
[该子方向的研究进展梳理，引用具体文献]
...

## 3. 研究趋势与热点
[基于文献时间分布和主题演变，分析研究趋势]

## 4. 现有研究的不足
[总结当前研究中存在的主要问题和空白]

## 5. 未来研究展望
[基于研究不足，提出未来可能的研究方向]

## 参考文献
[按引用顺序列出所有引用的文献，格式规范]

---
**综述统计：**
- 检索数据库：[使用的数据库列表]
- 检索时间范围：[起止年份]
- 初始检索文献数：[检索总量]
- 最终纳入文献数：[综述中实际引用数量]
```

## 质量要求

1. **文献覆盖**：每个子方向至少引用3-5篇代表性文献
2. **时间跨度**：兼顾经典文献和最新进展
3. **批判性分析**：不仅描述已有研究，还要分析优缺点
4. **逻辑连贯**：子方向之间有清晰的逻辑关系和过渡
5. **客观中立**：避免主观偏见，公正评价不同研究

## 示例工作流

```
用户: 帮我写一篇关于"图神经网络在药物发现中的应用"的文献综述，近3年的，中文

步骤1: 确认范围 → 图神经网络+药物发现，2023-2026，中文综述

步骤2: 多轮检索
- Google Scholar: "graph neural network drug discovery" (20条)
- ArXiv: "GNN drug discovery molecular" (100条)
- PubMed: "graph neural network drug discovery" (100条)
- 万方: "图神经网络 药物发现" (100条)
- Google Scholar: "molecular graph representation learning" (20条)
- PubMed: "deep learning molecular property prediction" (100条)

步骤3: 去重、筛选、分类
- 分子属性预测类
- 药物-靶点相互作用预测类
- 药物组合与协同效应类
- 从头药物设计类

步骤4: 生成综述报告

步骤5: 可选 - Python生成文献统计图表
```
