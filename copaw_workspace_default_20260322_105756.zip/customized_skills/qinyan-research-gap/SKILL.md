---
name: qinyan-research-gap
description: "沁言学术研究空白发现 - 通过沁言学术OpenAPI系统检索大量文献，结合Python分析，自动识别特定领域中的研究空白和薄弱环节，为科研选题和基金申请提供创新方向建议。触发词：研究空白、research gap、研究不足、创新点发现、gap analysis、研究机会、find gap、领域空白"
version: 1.0.0
---

# 沁言学术 - 研究空白发现

## 概述

本技能通过沁言学术OpenAPI从多个学术数据库系统检索大量文献，结合Python数据分析和AI推理能力，自动识别特定研究领域中的研究空白（Research Gap）。帮助科研人员发现创新研究方向，为选题论证和基金申请书中的"研究必要性"部分提供支撑。

**学术诚信声明：** 研究空白的识别基于对已检索文献的系统分析，受限于检索覆盖面。建议结合领域专家意见和更深入的文献调研进行验证。

## 前置条件

使用前请确保：
1. 已设置 `QINYAN_API_KEY` 环境变量（前往 https://platform.qinyanai.com/ 申请）
2. 环境中可用 `curl` 和 `python3`

```bash
export QINYAN_API_KEY="your-api-key-here"
```

## 研究空白类型

本技能关注以下几类研究空白：

| 空白类型 | 说明 | 识别方式 |
|----------|------|----------|
| **方法空白** | 现有方法未被应用到某些场景 | 交叉检索方法+场景 |
| **数据空白** | 缺乏特定数据集/语言/领域的研究 | 检索结果中缺失的维度 |
| **理论空白** | 缺乏理论解释或框架 | 实证研究多而理论研究少 |
| **规模空白** | 缺乏大规模/长期/多中心研究 | 分析现有研究的规模 |
| **交叉空白** | 学科交叉领域的研究不足 | 跨领域交叉检索 |
| **实践空白** | 理论研究多但实际应用少 | 对比理论vs应用类文献 |

## 工作流程

### 第一步：确定分析领域

与用户确认：
- **研究领域**：具体的研究方向
- **关注粒度**：宏观领域空白 / 微观技术空白
- **应用目的**：选题参考 / 基金申请 / 综述写作
- **用户背景**：已有的研究基础和资源条件

### 第二步：系统化多维文献检索

使用 `scripts/search.sh` 进行**多角度、多关键词组合**检索：

```bash
bash scripts/search.sh <source> '<json_payload>'
# source: google | wanfang | pubmed | arxiv
```

**各数据库参数：**

| 数据源 | 命令 | 核心参数 |
|--------|------|----------|
| Google Scholar | `bash scripts/search.sh google '<json>'` | query, max_results(≤20), date_from, date_to |
| 万方 | `bash scripts/search.sh wanfang '<json>'` | query, max_results(≤100), date_from, date_to |
| PubMed | `bash scripts/search.sh pubmed '<json>'` | query(英文), max_results(≤200), date_from, date_to |
| ArXiv | `bash scripts/search.sh arxiv '<json>'` | query(英文), max_results(≤100), date_from, date_to |

**多维检索策略：**

```bash
# 维度1：核心主题检索
bash scripts/search.sh arxiv '{"query": "federated learning healthcare", "max_results": 100, "date_from": "2021"}'

# 维度2：方法维度检索（哪些方法已被应用）
bash scripts/search.sh arxiv '{"query": "federated learning differential privacy medical", "max_results": 100}'
bash scripts/search.sh arxiv '{"query": "federated learning personalization clinical", "max_results": 100}'

# 维度3：应用场景维度（哪些场景已被覆盖）
bash scripts/search.sh pubmed '{"query": "federated learning radiology imaging", "max_results": 100}'
bash scripts/search.sh pubmed '{"query": "federated learning electronic health records", "max_results": 100}'
bash scripts/search.sh pubmed '{"query": "federated learning genomics", "max_results": 50}'

# 维度4：交叉领域检索（寻找交叉空白）
bash scripts/search.sh arxiv '{"query": "federated learning large language model", "max_results": 50}'
bash scripts/search.sh google '{"query": "federated learning edge computing IoT healthcare", "max_results": 20}'

# 维度5：中文文献检索（发现中文研究空白）
bash scripts/search.sh wanfang '{"query": "联邦学习 医疗", "max_results": 100}'
bash scripts/search.sh wanfang '{"query": "联邦学习 隐私保护 临床", "max_results": 100}'
```

### 第三步：Python分析研究覆盖度

使用Python脚本构建"研究覆盖矩阵"，识别空白区域：

```python
#!/usr/bin/env python3
"""研究空白分析 - 构建研究覆盖矩阵"""
import json
import collections
import sys

def build_coverage_matrix(papers, methods, scenarios):
    """
    构建方法×场景的覆盖矩阵
    methods: 方法关键词列表
    scenarios: 应用场景关键词列表
    """
    matrix = {m: {s: 0 for s in scenarios} for m in methods}

    for p in papers:
        text = (p.get('title', '') + ' ' + p.get('abstract', '')).lower()
        for m in methods:
            if m.lower() in text:
                for s in scenarios:
                    if s.lower() in text:
                        matrix[m][s] += 1

    # 输出覆盖矩阵
    print("=== 研究覆盖矩阵 (方法 × 场景) ===\n")
    header = "| 方法\\场景 | " + " | ".join(scenarios) + " |"
    sep = "|" + "---|" * (len(scenarios) + 1)
    print(header)
    print(sep)

    gaps = []
    for m in methods:
        row = f"| {m} | "
        cells = []
        for s in scenarios:
            count = matrix[m][s]
            if count == 0:
                cells.append("⬜ **空白**")
                gaps.append((m, s))
            elif count <= 2:
                cells.append(f"🟡 薄弱({count})")
                gaps.append((m, s))
            else:
                cells.append(f"🟢 {count}篇")
        row += " | ".join(cells) + " |"
        print(row)

    print(f"\n发现 {len(gaps)} 个研究空白/薄弱区域:")
    for m, s in gaps:
        count = matrix[m][s]
        status = "完全空白" if count == 0 else f"薄弱({count}篇)"
        print(f"  - {m} + {s}: {status}")

    return gaps

# 使用示例
if __name__ == '__main__':
    data = json.load(sys.stdin)
    papers = data if isinstance(data, list) else data.get('results', [])

    # 根据具体领域定义方法和场景关键词
    methods = ["transformer", "CNN", "GNN", "federated", "reinforcement"]
    scenarios = ["radiology", "pathology", "genomics", "EHR", "drug"]

    build_coverage_matrix(papers, methods, scenarios)
```

### 第四步：深度分析与验证

对初步识别的空白区域进行验证：
1. **针对性补充检索**：对疑似空白区域进行更精确的检索
2. **排除假阳性**：某些空白可能是因为术语差异导致
3. **评估可行性**：分析空白是否因客观原因（如数据不可得）而存在

### 第五步：生成研究空白报告

## 输出格式

```
# [研究领域] 研究空白分析报告

## 1. 分析概况
- 检索数据库：[使用的数据库]
- 检索文献总量：[数量]
- 时间范围：[年份]
- 分析维度：方法×场景 / 理论×实践 / 其他

## 2. 研究现状概览
[该领域当前研究的整体分布情况]

## 3. 研究覆盖矩阵
[Python生成的覆盖矩阵表格]

## 4. 发现的研究空白

### 空白 1：[空白描述]
- **空白类型**：方法空白 / 数据空白 / 交叉空白 / ...
- **具体描述**：[详细描述该空白]
- **现有最近研究**：[最相关的已有工作及其不足]
- **研究价值**：⭐⭐⭐⭐⭐ [高/中/低]
- **研究可行性**：⭐⭐⭐⭐ [高/中/低]
- **建议研究方向**：[可能的研究切入点]
- **支撑文献**：[相关文献引用]

### 空白 2：[空白描述]
- ...

### 空白 3：[空白描述]
- ...

## 5. 研究机会优先级排序

| 排名 | 研究空白 | 创新性 | 可行性 | 价值 | 综合推荐 |
|------|----------|--------|--------|------|----------|
| 1    | ...      | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | 强烈推荐 |
| 2    | ...      | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | 推荐 |
| 3    | ...      | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ | 推荐 |

## 6. 注意事项
- 本分析基于 [N] 篇检索文献，可能存在覆盖面不足的情况
- 建议结合领域专家意见进一步验证
- 研究空白的存在可能有客观原因（如数据获取困难）

## 参考文献
[引用的代表性文献]
```

## 分析质量要求

1. **检索充分**：每个分析维度至少100篇文献
2. **多维交叉**：至少从2个维度进行交叉分析
3. **验证空白**：对每个发现的空白进行补充检索验证
4. **评估可行性**：空白发现要结合实际可行性分析
5. **提供路径**：每个空白要给出可能的研究切入点

## 示例工作流

```
用户: 帮我发现"联邦学习在医疗领域应用"的研究空白

步骤1: 确认范围 → 联邦学习+医疗，重点关注方法和应用场景空白

步骤2: 多维检索
- 方法维度：差分隐私/个性化/异构/通信效率...
- 场景维度：影像/EHR/基因组/药物/可穿戴...
- 交叉维度：联邦+LLM/边缘计算/因果推理...

步骤3: Python构建覆盖矩阵，识别空白区域

步骤4: 对空白区域补充检索验证

步骤5: 生成研究空白报告，含优先级排序
```
