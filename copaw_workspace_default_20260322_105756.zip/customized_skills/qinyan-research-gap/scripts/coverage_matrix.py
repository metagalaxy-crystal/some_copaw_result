#!/usr/bin/env python3
"""
沁言学术 - 研究覆盖矩阵分析脚本
用法: cat papers.json | python3 coverage_matrix.py '["method1","method2"]' '["scenario1","scenario2"]'
输入: JSON格式的文献列表 + 方法关键词列表 + 场景关键词列表
"""
import json
import sys


def build_coverage_matrix(papers, methods, scenarios):
    """构建方法×场景的研究覆盖矩阵，识别空白区域"""

    matrix = {m: {s: [] for s in scenarios} for m in methods}

    for p in papers:
        text = ' '.join([
            p.get('title', ''),
            p.get('abstract', ''),
            ' '.join(p.get('keywords', [])) if isinstance(p.get('keywords'), list) else ''
        ]).lower()

        for m in methods:
            if m.lower() in text:
                for s in scenarios:
                    if s.lower() in text:
                        matrix[m][s].append(p.get('title', 'Unknown'))

    # 输出覆盖矩阵
    print(f"共分析 {len(papers)} 篇文献\n")
    print("=== 研究覆盖矩阵 (方法 × 场景) ===\n")

    # 表头
    header = "| 方法 \\ 场景 | " + " | ".join(scenarios) + " |"
    sep = "|---|" + "---|" * len(scenarios)
    print(header)
    print(sep)

    gaps = []
    weak = []
    for m in methods:
        cells = []
        for s in scenarios:
            count = len(matrix[m][s])
            if count == 0:
                cells.append("⬜ **空白**")
                gaps.append((m, s, count))
            elif count <= 2:
                cells.append(f"🟡 薄弱({count})")
                weak.append((m, s, count))
            elif count <= 5:
                cells.append(f"🟢 {count}篇")
            else:
                cells.append(f"🟢 {count}篇")
        row = f"| **{m}** | " + " | ".join(cells) + " |"
        print(row)

    # 输出空白区域
    if gaps:
        print(f"\n=== 发现 {len(gaps)} 个研究空白 ===")
        for m, s, _ in gaps:
            print(f"  ⬜ {m} × {s}: 完全空白 —— 未检索到相关文献")

    if weak:
        print(f"\n=== 发现 {len(weak)} 个薄弱区域 ===")
        for m, s, count in weak:
            print(f"  🟡 {m} × {s}: 仅 {count} 篇相关文献")
            for title in matrix[m][s]:
                print(f"     - {title[:80]}")

    total_cells = len(methods) * len(scenarios)
    filled = total_cells - len(gaps)
    print(f"\n=== 覆盖率统计 ===")
    print(f"  总分析维度: {total_cells}")
    print(f"  已覆盖: {filled} ({filled/total_cells*100:.1f}%)")
    print(f"  空白: {len(gaps)} ({len(gaps)/total_cells*100:.1f}%)")
    print(f"  薄弱: {len(weak)} ({len(weak)/total_cells*100:.1f}%)")

    return gaps, weak


def main():
    if len(sys.argv) < 3:
        print("用法: cat papers.json | python3 coverage_matrix.py '<methods_json>' '<scenarios_json>'")
        print("示例: cat papers.json | python3 coverage_matrix.py '[\"CNN\",\"GNN\",\"transformer\"]' '[\"imaging\",\"EHR\",\"genomics\"]'")
        sys.exit(1)

    try:
        methods = json.loads(sys.argv[1])
        scenarios = json.loads(sys.argv[2])
    except json.JSONDecodeError as e:
        print(f"Error: 参数JSON解析失败 - {e}", file=sys.stderr)
        sys.exit(1)

    try:
        data = json.load(sys.stdin)
    except json.JSONDecodeError as e:
        print(f"Error: 输入JSON解析失败 - {e}", file=sys.stderr)
        sys.exit(1)

    if isinstance(data, list):
        papers = data
    elif isinstance(data, dict):
        candidates = [data.get('data'), data.get('papers'), data.get('results')]
        papers = next((c for c in candidates if isinstance(c, list) and c), [])
    else:
        papers = []

    if not papers:
        print("Warning: 未找到论文数据")
        sys.exit(0)

    build_coverage_matrix(papers, methods, scenarios)


if __name__ == '__main__':
    main()
